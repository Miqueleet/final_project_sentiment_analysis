from flask import Flask, render_template, request, jsonify
import json
from EmotionDetection.emotion_detection import emotion_detector  # Adjust this import based on your project structure

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')  # This serves the index.html file

@app.route('/emotionDetector', methods=['GET', 'POST'])
def emotion_detection():
    # Handle GET request
    if request.method == 'GET':
        # Extract the 'textToAnalyze' parameter from the query string
        user_input = request.args.get('textToAnalyze', '')

    # Handle POST request
    elif request.method == 'POST':
        # Extract the 'text' parameter from the form data
        user_input = request.form['text']

    # Get the emotions as a dictionary from the emotion detection function
    emotions = emotion_detector(user_input)


    # Return the response as JSON

     # Check if dominant_emotion is None
    if emotions["dominant_emotion"] is None:
        return jsonify({"message": "Invalid text! Please try again!"}), 400

    # Format the output
    output = f"For the given statement, the system response is " \
             f"'anger': {emotions['anger']}, 'disgust': {emotions['disgust']}, " \
             f"'fear': {emotions['fear']}, 'joy': {emotions['joy']} and " \
             f"'sadness': {emotions['sadness']}. The dominant emotion is {emotions['dominant_emotion']}"

    return jsonify({"response": output})
         

    return output

if __name__ == '__main__':
    app.run(debug=True)
